library(readxl)
library(readr)
library(ggplot2)
library(dplyr)
library(RColorBrewer)
library(plotly)
library(ggplot2)
library(readxl)
library(lubridate)
library(ggpubr)
library(openxlsx)
library(grid)
library(tidyr)
library(tidyverse)
library(scales)
library(stringr) 
library(reshape2)
library(ggtext)
library("maps")
library(tigris)
library(sf)
library(openxlsx)

library(readr)
#LATEST PLATNING DATE----

process_file <- function(file_path) {
  # Read the first line for latitude and longitude
  first_line <- readLines(file_path, n = 1)
  coords <- strsplit(first_line, " ")[[1]]
  latitude <- coords[2]  # Assuming the second item is latitude
  longitude <- coords[5]  
  
  
  # Read the data from the 8th line
  data <- read_csv(file_path, skip = 7)
  
  # Reverse the data for backward accumulation
  data <- data[nrow(data):1, ]
  
  # Initialize variables
  accumulated_gdd <- 0
  latest_planting_day <- NA
  
  # Loop through each row backwards to calculate GDD and accumulate
  for (i in 1:nrow(data)) {
    avg_temp <- ((data$average_tmax[i]+1.5) + (data$average_tmin[i]+1.5)) / 2
    daily_gdd <- max(((9/5)*avg_temp + 32) - 60, 0)  # GDD in Fahrenheit
    accumulated_gdd <- accumulated_gdd + daily_gdd
    
    if (accumulated_gdd >= 2400) {
      latest_planting_day <- data$yday[i]
      break
    }
  }
  
  return(list(file = file_path, latitude = latitude, longitude = longitude, latest_planting_day = latest_planting_day, total_gdd = accumulated_gdd))
}
# Assuming all your files are in a directory "data_files"
#C:\Users\Sahila.Beegum\Documents\FiberQualityMap\R\R_Final\AllCottonGrownC_average15YWea
files <- list.files(path = "C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/AllCottonGrownC_average15YWea", full.names = TRUE)
#files <- list.files(path = "C:/Users/Sahila.Beegum/Documents/FiberQualityMap/PythonApplication1_15/Test", full.names = TRUE)
#file_path<-"C:/Users/Sahila.Beegum/Documents/FiberQualityMap/PythonApplication1_15/Test/ALABAMA_CHEROKEE"
# Process each file
results <- lapply(files, process_file)

# Convert to a dataframe for easier viewing/manipulation
results_df <- do.call(rbind, results)
results_df<-as.data.frame(results_df)
# Check and handle NA values in the dataframe
results_df[is.na(results_df)] <- "NA"  # Replace NA with "NA" or another placeholder


#write.xlsx(results_df, file="C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/latest_Mid_1.5_1.5.xlsx")

#FIRST PLATNING DATE----

process_file_earliest <- function(file_path) {
  # Read the first line for latitude and longitude
  first_line <- readLines(file_path, n = 1)
  coords <- strsplit(first_line, " ")[[1]]
  latitude <- coords[2]  # Assuming the second item is latitude
  longitude <- coords[5]
  
  # Read the data from the 8th line
  data <- read_csv(file_path, skip = 7)
  
  # Initialize variables
  consecutive_days_above_15 <- 0
  earliest_planting_day <- NA
  
  # Loop through each row to check average temperature
  for (i in 1:nrow(data)) {
    avg_temp <- ((data$average_tmax[i]+1.5) + (data$average_tmin[i]+1.5)) / 2
    
    if (avg_temp >= 15) {
      consecutive_days_above_15 <- consecutive_days_above_15 + 1
      if (consecutive_days_above_15 >= 7) {
        earliest_planting_day <- data$yday[i]
        break
      }
    } else {
      consecutive_days_above_15 <- 0  # Reset count if temperature drops below 15
    }
  }
  
  return(list(file = file_path, latitude = latitude, longitude = longitude, earliest_planting_day = earliest_planting_day))
}

# Process each file for earliest planting date
results_earliest <- lapply(files, process_file_earliest)

# Convert to a dataframe
results_earliest_df <- do.call(rbind, results_earliest)
results_earliest_df <- as.data.frame(results_earliest_df)

# Write to Excel
Data<-cbind(results_earliest_df,results_df)
write.xlsx(Data, file="C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/Earliest_latest.xlsx")


wb <- read_excel("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/StandardList.xlsx")
wb1 <- loadWorkbook("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/Earliest_latest.xlsx")
 
wb$earliest_planting_day<-ifelse(is.na(Data$earliest_planting_day), NA, as.numeric(Data$earliest_planting_day))
wb$latest_planting_day<-ifelse(is.na(Data$latest_planting_day), NA, as.numeric(Data$latest_planting_day))
wb$total_gdd<-ifelse(is.na(Data$total_gdd), NA, as.numeric(Data$total_gdd))
 
# save the changes to the Excel file
#write.xlsx(wb, file="C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/Earliest_latest.xlsx", sheet="Sheet1")

 # Create a new worksheet
addWorksheet(wb1, "Sheet1")

# Add data to the new worksheet
 
writeData(wb1, "Sheet1",wb)

# Save the changes to the Excel file
saveWorkbook(wb1, "C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/Earliest_latest.xlsx", overwrite = TRUE)

#plot in a mp----


#getting data with all counties ans states----
# Set options to allow larger downloads
options(tigris_use_cache = TRUE)

# Download county data for the United States
counties <- counties(cb = TRUE, class = "sf")

# Calculate the centroids
centroids <- st_centroid(counties)

# Extract longitude and latitude
centroid_coords <- st_coordinates(centroids)

# Combine the data
county_data <- cbind(counties, centroid_coords)

# View the data
head(county_data)
county_data<-as.data.frame(county_data)

CountyLatLon<-county_data[,c(6,9,13,14)]

names(CountyLatLon)[1]="county"
names(CountyLatLon)[3]="Latitude"
names(CountyLatLon)[4]="Longitude"
names(CountyLatLon)[2]="State"
CountyLatLon$county<-toupper(CountyLatLon$county)
CountyLatLon$State<-toupper(CountyLatLon$State)

#Excelsheet with cotton grown locaitons----

data <- read_excel("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/Earliest_latest.xlsx", sheet="Sheet1")
data<-as.data.frame(data)
#data <- data[data$LAST != 0, ]


names(data)[2]="county"

#merging counties with cotton----
merged<- merge(data,CountyLatLon, by=c("county","State"))

usa_map <- map_data("state")
gg <- ggplot() +
  geom_polygon(data = usa_map, aes(x = long, y = lat, group = group), fill = "white", color = "black") +
  coord_fixed(1.3) # to maintain aspect ratio

A <- gg #+ geom_point(data = merged, aes(y = Longitude, x = Latitude), color = "red", size = 1)

#spatialfill counties----

# Load necessary packages
library(tigris)
library(sf)
library(ggplot2)
library(dplyr)

# Set options
options(tigris_use_cache = TRUE)

# Assuming 'merged' is your loaded data frame
my_data <- merged

# List of states in the continental US
mainland_states <- c("AL", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", 
                     "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", 
                     "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", 
                     "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", 
                     "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", 
                     "WV", "WI", "WY")

# Download county data and filter for continental US
counties <- counties(cb = TRUE, class = "sf") %>%
  filter(STUSPS %in% mainland_states) %>%
  mutate(county_name = tolower(NAME), state_name = tolower(STATE_NAME))

# Prepare your data (convert county and state names to lower case for matching)
my_data$county <- tolower(my_data$county)
my_data$State <- tolower(my_data$State)

# Merge your data with the county data
merged_data <- counties %>%
  left_join(my_data, by = c("county_name" = "county", "state_name" = "State"))

# Create a new column to indicate presence of your points
merged_data$has_point <- !is.na(merged_data$Latitude)

NewData<-select(merged_data,county_name,state_name, Latitude, Longitude,earliest_planting_day,latest_planting_day,total_gdd)


library(dplyr)
NewData <- NewData %>%
  filter(!is.na(Latitude))
NewData$latest_planting_day<-as.numeric(NewData$latest_planting_day)
NewData  = NewData[NewData$earliest_planting_day - 6 <= NewData$latest_planting_day,]
SavelatlonConty<-NewData[c("county_name","state_name","Latitude","Longitude")]
SavelatlonConty<-as.data.frame(SavelatlonConty)
# 
# # Calculate the range for each variable
# range_FQM <- range(NewData$FQM, na.rm = TRUE)
# range_FQL <- range(NewData$FQL, na.rm = TRUE)
range_LPD <- range(NewData$latest_planting_day, na.rm = TRUE)
range_EPD <- range(NewData$earliest_planting_day, na.rm = TRUE)
range_GDD <- range(NewData$total_gdd, na.rm = TRUE)
# Plot the map
Fig1<-A+
  geom_sf(data = NewData, aes(fill = earliest_planting_day)) +
  scale_fill_distiller(palette = "Spectral", range_EPD, name = "Earliest planting day") +
  theme_minimal() +
  labs(fill =  "Earliest planting day")+
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 
Fig1<-A+
  geom_sf(data = NewData, aes(fill = earliest_planting_day)) +
  scale_fill_distiller(palette = "Spectral",  limits = c(0,230), name = "Earliest planting day") +
  theme_minimal() +
  labs(fill =  "Earliest planting day")+
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 

# Plot the map
Fig2<-A+
  geom_sf(data = NewData, aes(fill = latest_planting_day)) +
  scale_fill_distiller(palette = "Spectral", limits =range_LPD, name = "Late planting day") +
  theme_minimal() +
  labs(fill = "Late planting day")+
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 
Fig2<-A+
  geom_sf(data = NewData, aes(fill = latest_planting_day)) +
  scale_fill_distiller(palette = "Spectral", limits = c(0,230), name = "Late planting day") +
  theme_minimal() +
  labs(fill = "Late planting day")+
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 
Fig3<-A+
  geom_sf(data = NewData, aes(fill = total_gdd)) +
  scale_fill_distiller(palette = "Spectral", limits =  range_GDD, name = "GDD") +
  theme_minimal() +
  labs(fill = "GDD")+
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 
Fig4<-A+
  geom_sf(data = NewData, aes(fill = latest_planting_day-earliest_planting_day)) +
  scale_fill_distiller(palette = "Spectral", limits = c(0,230), name = "Planting interval") +
  theme_minimal() +
  labs(fill = "Planting interval")+
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 
# Plot the map

ggsave("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/Earlist.pdf", plot=Fig1)
ggsave("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/Latest.pdf", plot=Fig2)
ggsave("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/GDD.pdf", plot=Fig3)
ggsave("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/PI.pdf", plot=Fig4) 




library(GA)

#GA----

#to estimate the best we used a seperate function----
calculate_fitnessresult <- function(planting_date, weather_data) {
  # [Your existing logic to process weather data and calculate fiber quality metrics]
  # Return the sum of fiber quality metrics as the fitness value
  
  
  # Process the weather data
  weather_data <- weather_data %>% 
    mutate(State = state, County = county, Latitude = latitude, Longitude = longitude,
           year = as.numeric(year),
           yday = as.numeric(yday),
           `average_tmax` = as.numeric(`average_tmax`)+1.5,
           `average_tmin` = as.numeric(`average_tmin`)+1.5,
           Tavg = (`average_tmax`+1.5 + `average_tmin`+1.5) / 2) %>%
    left_join(PlantingDate, by = "State")
  
  # Calculate running average temperature starting from yday 155
  
  # Calculate modified running average temperature starting from yday = PD
  weather_data <- weather_data %>%
    arrange(year, yday) %>%
    group_by(year) %>%
    mutate(RunningAvgTemp = calculate_running_avg(cur_data(), planting_date))
  
  # Calculate TSQ based on RunningAvgTemp with constraints
  weather_data <- weather_data %>%
    mutate(RunningAvgTempAdjusted = pmax(pmin(RunningAvgTemp, 35), 17),
           TSQ = 190.33 - 11.37 * RunningAvgTempAdjusted + 0.194 * RunningAvgTempAdjusted^2)
  
  selected_rows <- weather_data %>%
    filter(!is.na(TSQ ) & TSQ  > (yday - planting_date)) %>%
    mutate(Difference = yday - planting_date)
  
  # time to first squre
  timetofirstsquare=max(selected_rows$yday)-min(selected_rows$yday)
  #start day for finding out the first flower
  FFstartday<-max(selected_rows$yday)
  
  # Calculate running average temperature starting from FFstartday
  weather_data <- weather_data %>%
    mutate(RunningAvgTempFF = calculate_running_avg(cur_data(), FFstartday))
  
  # Calculate TFF with constraints
  weather_data <- weather_data %>%
    mutate(RunningAvgTempFFAdjusted = pmax(pmin(RunningAvgTempFF, 32), 17),
           TFF = 252.59 - 15.32 * RunningAvgTempFFAdjusted + 0.2531 * RunningAvgTempFFAdjusted^2)
  
  selected_rows <- weather_data %>%
    filter(!is.na(TFF) & TFF > (yday - FFstartday)) %>%
    mutate(Difference = yday - FFstartday)
  #time from square to flower
  timefromfirstsqtoflower=max(selected_rows$yday)-min(selected_rows$yday)
  
  FOBstartday<-max(selected_rows$yday)
  
  
  # Calculate running average temperature starting from FFstartday
  weather_data <- weather_data %>%
    mutate(RunningAvgTempFOB = calculate_running_avg(cur_data(),  FOBstartday))
  
  # Calculate TFF with constraints
  weather_data <- weather_data %>%
    mutate(RunningAvgTempFOBAdjusted = pmax(pmin(RunningAvgTempFOB, 35), 17),
           TFOB =327.39 - 17.25 * RunningAvgTempFOBAdjusted + 0.255 * RunningAvgTempFOBAdjusted^2)
  
  selected_rows <- weather_data %>%
    filter(!is.na(TFOB) & TFOB > (yday - FOBstartday)) %>%
    mutate(Difference = yday - FOBstartday)
  #time from square to flower
  timefromfirstflowertoopenboll=max(selected_rows$yday)-min(selected_rows$yday)
  
  RunningAvgTempFlowerOpenboll<-tail(selected_rows$RunningAvgTempFOBAdjusted,n=1)
  
  #FQ
  FStrength<-21.817+0.341*RunningAvgTempFlowerOpenboll
  FLength<-11.5+1.75*RunningAvgTempFlowerOpenboll-0.04*RunningAvgTempFlowerOpenboll*RunningAvgTempFlowerOpenboll
  FMicronaire<--6.88+0.843*RunningAvgTempFlowerOpenboll-0.017*RunningAvgTempFlowerOpenboll*RunningAvgTempFlowerOpenboll
  FUniformity<-55.04+2.37*RunningAvgTempFlowerOpenboll-0.047*RunningAvgTempFlowerOpenboll*RunningAvgTempFlowerOpenboll
  
  
  fitness_value<-FStrength + FLength + FMicronaire + FUniformity
  return(list(FStrength = FStrength, FLength = FLength, FMicronaire = FMicronaire, 
              FUniformity = FUniformity, TotalFitness = fitness_value,
              timefromfirstflowertoopenboll=timefromfirstflowertoopenboll,
              timefromfirstsqtoflower=timefromfirstsqtoflower,
              timetofirstsquare=timetofirstsquare,
              RunningAvgTempFlowerOpenboll=RunningAvgTempFlowerOpenboll))
  
  
}



# Function to calculate running average temperature from a specific start day
calculate_running_avg <- function(data, start_day) {
  running_avg <- numeric(length(data$Tavg))
  running_sum <- 0
  count <- 0
  for (i in seq_along(data$Tavg)) {
    if (data$yday[i] >= start_day) {
      running_sum <- running_sum + data$Tavg[i]
      count <- count + 1
      running_avg[i] <- running_sum / count
    } else {
      running_avg[i] <- NA
    }
  }
  return(running_avg)
}

# Function to calculate combined fitness for a given planting date
calculate_fitness <- function(planting_date, weather_data) {
  # [Your existing logic to process weather data and calculate fiber quality metrics]
  # Return the sum of fiber quality metrics as the fitness value
  
  
  # Process the weather data
  weather_data <- weather_data %>% 
    mutate(State = state, County = county, Latitude = latitude, Longitude = longitude,
           year = as.numeric(year),
           yday = as.numeric(yday),
           `average_tmax` = as.numeric(`average_tmax`)+1.5,
           `average_tmin` = as.numeric(`average_tmin`)+1.5,
           Tavg = (`average_tmax`+1.5 + `average_tmin`+1.5) / 2) %>%
    left_join(PlantingDate, by = "State")
  
  # Calculate running average temperature starting from yday 155
  
  # Calculate modified running average temperature starting from yday = PD
  weather_data <- weather_data %>%
    arrange(year, yday) %>%
    group_by(year) %>%
    mutate(RunningAvgTemp = calculate_running_avg(cur_data(), planting_date))
  
  # Calculate TSQ based on RunningAvgTemp with constraints
  weather_data <- weather_data %>%
    mutate(RunningAvgTempAdjusted = pmax(pmin(RunningAvgTemp, 35), 17),
           TSQ = 190.33 - 11.37 * RunningAvgTempAdjusted + 0.194 * RunningAvgTempAdjusted^2)
  
  selected_rows <- weather_data %>%
    filter(!is.na(TSQ ) & TSQ  > (yday - planting_date)) %>%
    mutate(Difference = yday - planting_date)
  
  # time to first squre
  timetofirstsquare=max(selected_rows$yday)-min(selected_rows$yday)
  #start day for finding out the first flower
  FFstartday<-max(selected_rows$yday)
  
  # Calculate running average temperature starting from FFstartday
  weather_data <- weather_data %>%
    mutate(RunningAvgTempFF = calculate_running_avg(cur_data(), FFstartday))
  
  # Calculate TFF with constraints
  weather_data <- weather_data %>%
    mutate(RunningAvgTempFFAdjusted = pmax(pmin(RunningAvgTempFF, 32), 17),
           TFF = 252.59 - 15.32 * RunningAvgTempFFAdjusted + 0.2531 * RunningAvgTempFFAdjusted^2)
  
  selected_rows <- weather_data %>%
    filter(!is.na(TFF) & TFF > (yday - FFstartday)) %>%
    mutate(Difference = yday - FFstartday)
  #time from square to flower
  timefromfirstsqtoflower=max(selected_rows$yday)-min(selected_rows$yday)
  
  FOBstartday<-max(selected_rows$yday)
  
  
  # Calculate running average temperature starting from FFstartday
  weather_data <- weather_data %>%
    mutate(RunningAvgTempFOB = calculate_running_avg(cur_data(),  FOBstartday))
  
  # Calculate TFF with constraints
  weather_data <- weather_data %>%
    mutate(RunningAvgTempFOBAdjusted = pmax(pmin(RunningAvgTempFOB, 35), 17),
           TFOB =327.39 - 17.25 * RunningAvgTempFOBAdjusted + 0.255 * RunningAvgTempFOBAdjusted^2)
  
  selected_rows <- weather_data %>%
    filter(!is.na(TFOB) & TFOB > (yday - FOBstartday)) %>%
    mutate(Difference = yday - FOBstartday)
  #time from square to flower
  timefromfirstflowertoopenboll=max(selected_rows$yday)-min(selected_rows$yday)
  
  RunningAvgTempFlowerOpenboll<-tail(selected_rows$RunningAvgTempFOBAdjusted,n=1)
  
  #FQ
  FStrength<-21.817+0.341*RunningAvgTempFlowerOpenboll
  FLength<-11.5+1.75*RunningAvgTempFlowerOpenboll-0.04*RunningAvgTempFlowerOpenboll*RunningAvgTempFlowerOpenboll
  FMicronaire<--6.88+0.843*RunningAvgTempFlowerOpenboll-0.017*RunningAvgTempFlowerOpenboll*RunningAvgTempFlowerOpenboll
  FUniformity<-55.04+2.37*RunningAvgTempFlowerOpenboll-0.047*RunningAvgTempFlowerOpenboll*RunningAvgTempFlowerOpenboll
  
  
  fitness_value<-FStrength + FLength + FMicronaire + FUniformity
  return(fitness_value)
}

# Load PlantingDate data
PlantingDate <- read_excel("~/FiberQualityMap/PlantingDate.xlsx")

# Final dataframe to store results
final_results <- data.frame(State = character(), County = character(), 
                            BestPlantingDate = integer(), 
                            FStrength = numeric(), FLength = numeric(), 
                            FMicronaire = numeric(), FUniformity = numeric(), 
                            stringsAsFactors = FALSE)


# Read the Excel sheet
planting_days_df <- read_excel("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/Earliest_latest.xlsx")

files <- list.files("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/AllCottonGrownC_average15YWea", full.names = TRUE)
for (file in files) {
  filename <- basename(file)
  file_parts <- strsplit(filename, "_")[[1]]
  state <- file_parts[1]
  county <- file_parts[2]
  
  # Match filename with the Excel sheet and extract planting days
  matching_row <- planting_days_df[planting_days_df$file...1 == file, ]
  latest_planting_day <- as.numeric(matching_row$latest_planting_day)
  earliest_planting_day <- as.numeric(matching_row$earliest_planting_day)-6
  
  # Skip GA if NA in either column
  if (is.na(latest_planting_day) || is.na(earliest_planting_day)) {
    next
  }
  
  if (latest_planting_day<earliest_planting_day) {
    next
  }
  
  
  # Step 4: Read the first line to get latitude and longitude
  first_line <- readLines(file, n = 1)
  coords <- strsplit(first_line, " ")[[1]]
  latitude <- coords[2]  # Assuming the second item is latitude
  longitude <- coords[5] # Assuming the fifth item is longitude
  
  
  # Step 5: Read the file excluding the first 8 lines
  weather_data <- read_csv(file, skip = 7)
  
  
  
  ga_result <- ga(
    type = "real-valued",
    fitness = function(x) calculate_fitness(x, weather_data),
    lower = earliest_planting_day, 
    upper = latest_planting_day, 
    popSize = 10, 
    maxiter = 3  
  )
  best_planting_dates <- min(ga_result@solution[, 1])
  
  # Iterate over each best planting date
  for (date in best_planting_dates) {
    # Recalculate fiber quality metrics for each planting date
    
    best_quality <- calculate_fitnessresult( date, weather_data)
    
    # Append results to final dataframe
    final_results <- rbind(final_results, data.frame(
      State = state,
      County = county,
      PLtDate = date,
      FStrength = best_quality$FStrength,
      FLength = best_quality$FLength,
      FMicronaire = best_quality$FMicronaire,
      FUniformity = best_quality$FUniformity,
      timeToSQ = best_quality$timetofirstsquare,  
      timeToFF = best_quality$timefromfirstsqtoflower,
      timeToOB = best_quality$timefromfirstflowertoopenboll,
      AvgTempFtoOB = best_quality$RunningAvgTempFlowerOpenboll,
      Lat<-latitude ,   # Assuming the second item is latitude
      Lon<-longitude
    ))
  }
  
}


# Write final results to Excel
write.xlsx(final_results, "C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/FinalOptimalPlantingDates.xlsx")




#PLANTING DATE OPTIMUM AND FQ MAP----

#getting data with all counties ans states----
# Set options to allow larger downloads
options(tigris_use_cache = TRUE)

# Download county data for the United States
counties <- counties(cb = TRUE, class = "sf")

# Calculate the centroids
centroids <- st_centroid(counties)

# Extract longitude and latitude
centroid_coords <- st_coordinates(centroids)

# Combine the data
county_data <- cbind(counties, centroid_coords)

# View the data
head(county_data)
county_data<-as.data.frame(county_data)

CountyLatLon<-county_data[,c(6,9,13,14)]

names(CountyLatLon)[1]="county"
names(CountyLatLon)[3]="Latitude"
names(CountyLatLon)[4]="Longitude"
names(CountyLatLon)[2]="State"
CountyLatLon$county<-toupper(CountyLatLon$county)
CountyLatLon$State<-toupper(CountyLatLon$State)

#Excelsheet with cotton grown locaitons----
data <- read_excel("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/FinalOptimalPlantingDates.xlsx", sheet="Sheet 1")
data<-as.data.frame(data)
names(data)[2]="county"

#merging counties with cotton----
merged<- merge(data,CountyLatLon, by=c("county","State"))

#plotting map----
usa_map <- map_data("state")

gg <- ggplot() +
  geom_polygon(data = usa_map, aes(x = long, y = lat, group = group), fill = "white", color = "black") +
  coord_fixed(1.3) +
  scale_x_continuous(expand = c(0, 0)) +
  scale_y_continuous(expand = c(0, 0))# to maintain aspect ratio
A <- gg #+ geom_point(data = merged, aes(y = Longitude, x = Latitude), color = "red", size = 1)

#spatialfill counties----

# Load necessary packages
library(tigris)
library(sf)
library(ggplot2)
library(dplyr)

# Set options
options(tigris_use_cache = TRUE)

# Assuming 'merged' is your loaded data frame
my_data <- merged

# List of states in the continental US
mainland_states <- c("AL", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", 
                     "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", 
                     "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", 
                     "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", 
                     "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", 
                     "WV", "WI", "WY")

# Download county data and filter for continental US
counties <- counties(cb = TRUE, class = "sf") %>%
  filter(STUSPS %in% mainland_states) %>%
  mutate(county_name = tolower(NAME), state_name = tolower(STATE_NAME))

# Prepare your data (convert county and state names to lower case for matching)
my_data$county <- tolower(my_data$county)
my_data$State <- tolower(my_data$State)

# Merge your data with the county data
merged_data <- counties %>%
  left_join(my_data, by = c("county_name" = "county", "state_name" = "State"))

# Create a new column to indicate presence of your points
merged_data$has_point <- !is.na(merged_data$Latitude)

NewData<-select(merged_data,county_name,state_name, Latitude, Longitude,PLtDate, FMicronaire,
                FStrength,FLength,FUniformity,timeToSQ,timeToFF,timeToOB, AvgTempFtoOB)

merged_data$FMicronaire
merged_data$FStrength
merged_data$FLength
merged_data$FUniformity
merged_data$timeToSQ
merged_data$timeToFF
merged_data$timeToOB
merged_data$AvgTempFtoOB
merged_data$PLtDate

library(dplyr)
NewData <- NewData %>%
  filter(!is.na(Latitude))

SavelatlonConty<-NewData[c("county_name","state_name","Latitude","Longitude")]
SavelatlonConty<-as.data.frame(SavelatlonConty)

# Calculate the range for each variable
range_FQM <- range(NewData$FMicronaire, na.rm = TRUE)
range_FQL <- range(NewData$FLength, na.rm = TRUE)
range_FQU <- range(NewData$FUniformity, na.rm = TRUE)
range_FQS <- range(NewData$FStrength, na.rm = TRUE)
range_PLtDate<- range(NewData$PLtDate, na.rm = TRUE)
range_AvgTempFtoOB<- range(NewData$AvgTempFtoOB,na.rm = TRUE)

range_FQM
range_FQL
range_FQU
range_FQS
range_PLtDate 
range_AvgTempFtoOB 



range_FQM <- c(1.7,3.6)
range_FQL <- c(23, 31)
range_FQU <- c(80, 85)
range_FQS <- c(29, 34)
range_PLtDate<- c(0, 260)
range_AvgTempFtoOB<- c(20, 40)

# Plot the map
Fig1<-A+
  geom_sf(data = NewData, aes(fill = FMicronaire)) +
  scale_fill_distiller(palette = "Spectral", limits = range_FQM, name = "Micronaire") +
  theme_minimal() +
  labs(fill = "Micronaire")+
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 
# Plot the map
Fig2<-A+
  geom_sf(data = NewData, aes(fill = FLength )) +
  scale_fill_distiller(palette = "Spectral", limits = range_FQL, name = "Fiber Length (mm)") +
  theme_minimal() +
  labs(fill = "Length")+
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 
Fig3<-A+
  geom_sf(data = NewData, aes(fill = FUniformity)) +
  scale_fill_distiller(palette = "Spectral", limits = range_FQU, name = "Fiber uniformity (%)") +
  theme_minimal() +
  labs(fill = "Uniformity") +
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 
# Plot the map
Fig4<-A+
  geom_sf(data = NewData, aes(fill = FStrength)) +
  scale_fill_distiller(palette = "Spectral", limits = range_FQS, name = "Fiber strength (g/tex)") +
  theme_minimal() +
  labs(fill = "Strength")+
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 
Fig5<-A+
  geom_sf(data = NewData, aes(fill = PLtDate)) +
  scale_fill_distiller(palette = "Spectral", limits = range_PLtDate, name = "Planting day") +
  theme_minimal() +
  labs(fill = "Planting day")+
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 
Fig6<-A+
  geom_sf(data = NewData, aes(fill = AvgTempFtoOB)) +
  scale_fill_distiller(palette = "Spectral", limits = range_AvgTempFtoOB, name = "AvgTemp") +
  theme_minimal() +
  labs(fill = "AvgTemp")+
  theme(
    axis.text = element_text(color = "black", size = 14),  # Increase text size for axis text
    axis.title.x = element_text(color = "black", size = 16),  # Increase text size for x-axis title
    axis.title.y = element_text(color = "black", size = 16),  # Increase text size for y-axis title
    axis.text.x = element_text(color = "black", size = 14),  # Increase text size for x-axis labels
    axis.text.y = element_text(color = "black", size = 14),  # Increase text size for y-axis labels
    legend.text = element_text(color = "black", size = 14),  # Increase text size for legend text
    legend.title = element_text(color = "black", size = 16)  # Increase text size for legend title
  ) +
  xlab("Longitude") +
  ylab("Latitude") + 
  theme(
    legend.position = "bottom",  # Place legend at the bottom
    legend.direction = "horizontal",  # Make the legend horizontal
    legend.key.width = unit(2, "cm")  # Extend the legend color bar width
  ) +
  guides(fill = guide_colorbar(barwidth = 20, barheight = 1)) 
FQ<-ggarrange(Fig2,Fig4,Fig1,Fig3, nrow=2, ncol=2)
#ggsave("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code_Mid_1.5/Micronaire.pdf", plot=Fig1)
#ggsave("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code_Mid_1.5/Length.pdf", plot=Fig2)
#ggsave("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code_Mid_1.5/Uniformity.pdf", plot=Fig3)
#ggsave("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code_Mid_1.5/Strength.pdf", plot=Fig4)
ggsave("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/Planting_day.pdf", plot=Fig5)
ggsave("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/AvgTemp.pdf", plot=Fig6)
ggsave("C:/Users/Sahila.Beegum/Documents/FiberQualityMap/Single_Code/Mid_1.5/FQ.pdf", plot=FQ,width = 15, height = 8)






  